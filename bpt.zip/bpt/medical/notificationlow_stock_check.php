<?php
include 'assets/db.php';

$threshold = 3; // Set low stock threshold

$query = "SELECT name, unit, quantity FROM inventeries WHERE quantity < $threshold";
$result = mysqli_query($con, $query);

if (mysqli_num_rows($result) > 0) {
    echo "<div class='low-stock-notification'>";
    echo "<strong>⚠️ Low Stock Alert:</strong> The following items have low stock:<ul>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>{$row['name']} ({$row['unit']}) - Only <b>{$row['quantity']}</b> left</li>";
    }
    echo "</ul></div>";
}
?>
